package cz.cvut.agents.rph.reversi.players;

import java.awt.Point;
import java.util.List;

/**
 * Very standart implementation of MiniMax algorithm with AlphaBeta pruning 
 * 
 * Some methods ported from http://www.cs.cornell.edu/~yuli/othello/othello.html and
 * some another sources. (Most of them dated 97-99, but they very simple and very strong)
 *
 * @autor iliusvla
 */
public class MiniMax {

    private final int Alpha = Integer.MIN_VALUE;
    private final int Beta = Integer.MAX_VALUE;
    private int bestValue;
    private int depth;
    private int myColor;
    private Board board;
    public Point bestMove = new Point();

    public MiniMax(Board board, int myColor, int depth) {
        bestValue = Alpha;
        this.board = board;
        this.myColor = myColor;
        this.depth = depth;
        alphaBeta();
    }

    public void alphaBeta() {

        for (Point move : board.getPossibleMoves(myColor)) {

            Board nextBoardState = new Board(board.board, true);

            nextBoardState.setBoard(move.x, move.y, myColor);

            int oppBeta = Beta;

            if (bestValue != Alpha) {
                oppBeta = -1 * bestValue;
            }

            int val = -1 * getCoast(nextBoardState, depth, Alpha, oppBeta, PlayerIliusvla.changeColor(myColor));
            if (bestValue == Alpha || val > bestValue) {
                bestValue = val;
                bestMove.x = move.x;
                bestMove.y = move.y;
            }
        }
    }

   
    private int getCoast(Board br, int maxDepth, int alpha, int beta, int color) {

        List<Point> possibleMoves = br.getPossibleMoves(color);

        if (possibleMoves.isEmpty()) {
            color = PlayerIliusvla.changeColor(color);
            possibleMoves = br.getPossibleMoves(color);
        }

        if (possibleMoves.isEmpty() || maxDepth == 0 || (System.nanoTime() - PlayerIliusvla.startTime) > 980000000) {
            return br.evaluate(color);
        }

        for (Point move : possibleMoves) {

            Board newBoard = new Board(br.board, true);

            newBoard.setBoard(move.x, move.y, color);

            int opponentΑlpha = Alpha;
            int opponentBeta = Beta;

            if (alpha != Alpha) {
                opponentBeta = -1 * alpha;
            }

            if (beta != Beta) {
                opponentΑlpha = -1 * beta;
            }

            int val = -1 * getCoast(newBoard, maxDepth - 1, opponentΑlpha, opponentBeta, PlayerIliusvla.changeColor(color));

            if (alpha == Alpha || val > alpha) {
                alpha = val;
            }

            if (alpha != Alpha && beta != Beta && alpha >= beta) {
                return beta;
            }
        }
        return alpha;
    }
}