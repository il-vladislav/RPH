/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.cvut.agents.rph.reversi.players;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author iliusvla
 */
public class Board {

    public int[][] board;
    public int size;
    private int[] dxArr = new int[]{-1, 0, 1};
    private int[] dyArr = new int[]{-1, 0, 1};

    public Board(int[][] board, boolean copy) {
        size = board.length;

        if (copy) {
            this.board = Copy(board);
        } else {
            this.board = board;
        }
    }

    boolean setBoard(int col, int row, int color) {
        return checkMove(col, row, color, true);
    }

   
    int totalStones() {
        int count = 0;
        count += stonesCounter(PlayerIliusvla.myColor);
        count += stonesCounter(PlayerIliusvla.changeColor(PlayerIliusvla.myColor));
        return count;
    }

    private int stonesCounter(int color) {
        int count = 0;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (board[i][j] == color) {
                    count++;
                }
            }
        }
        return count;
    }

   
    public int evaluate(int color) {
        int countGoodnes = 0;
        boolean early_game = (totalStones() < 40);
        int enemyStones = stonesCounter(PlayerIliusvla.changeColor(color));
        int friendlyStones = stonesCounter(color);
        int K1 = 1, K2 = 2, K3 = 3;

        int stability = (GetStableDiscsCount(board, color, PlayerIliusvla.changeColor(color)) - GetStableDiscsCount(board, PlayerIliusvla.changeColor(color), color)) * board.length * 2 / 3;

        if (early_game) {
            // give-away in the early game
            countGoodnes = K1 * (enemyStones - friendlyStones) + stability / 2;
        } else {
            // take-back later in the game
            countGoodnes = K2 * (friendlyStones - enemyStones);
        }
        int positionalGoodness = K3 * positionMatrixEvualation(color);
        int total_board_goodness = countGoodnes + positionalGoodness;

        return total_board_goodness;
    }

    int positionMatrixEvualation(int color) {
        int score = 0;

        int opColor = PlayerIliusvla.changeColor(color);

        int payOut = 0;

        for (int col = 0; col < size; col++) {
            for (int row = 0; row < size; row++) {
                payOut = 0;

                if (col == 0 || row == size - 1) {
                    payOut += 10;
                }
                if (row == 0 || col == size - 1) {
                    payOut += 10;
                }
                if (col == 1 || row == size - 2) {
                    payOut -= 5;
                }
                if (row == 1 || col == size - 2) {
                    payOut -= 5;
                }

                if (board[col][row] == color) {
                    score += payOut;
                } else if (board[col][row] == opColor) {
                    score -= payOut;
                }
            }
        }
        return score;
    }

    public int GetStableDiscsCount(int[][] board, int color, int oppositecolor) {
        return this.GetStableDiscsFromCorner(board, color, 0, 0)
                + this.GetStableDiscsFromCorner(board, color, 0, board.length - 1)
                + this.GetStableDiscsFromCorner(board, color, board.length - 1, 0)
                + this.GetStableDiscsFromCorner(board, color, board.length - 1, board.length - 1)
                + this.GetStableDiscsFromEdge(board, color, 0, true)
                + this.GetStableDiscsFromEdge(board, color, board.length - 1, true)
                + this.GetStableDiscsFromEdge(board, color, 0, false)
                + this.GetStableDiscsFromEdge(board, color, board.length - 1, false);
    }

    private int GetStableDiscsFromCorner(int[][] board, int color, int cornerRowIndex, int cornerColumnIndex) {
        int result = 0;

        int rowIndexChange = (cornerRowIndex == 0) ? 1 : -1;
        int columnIndexChange = (cornerColumnIndex == 0) ? 1 : -1;

        int rowIndex = cornerRowIndex;
        int rowIndexLimit = (cornerRowIndex == 0) ? board.length : 0;
        int columnIndexLimit = (cornerColumnIndex == 0) ? board.length : 0;
        for (rowIndex = cornerRowIndex; rowIndex != rowIndexLimit; rowIndex += rowIndexChange) {
            int columnIndex;
            for (columnIndex = cornerColumnIndex; columnIndex != columnIndexLimit; columnIndex += columnIndexChange) {
                if (board[rowIndex][columnIndex] == color) {
                    result++;
                } else {
                    break;
                }
            }

            if ((columnIndexChange > 0 && columnIndex < board.length) || (columnIndexChange < 0 && columnIndex > 0)) {
                columnIndexLimit = columnIndex - columnIndexChange;

                if (columnIndexChange > 0 && columnIndexLimit == 0) {
                    columnIndexLimit++;
                } else if (columnIndexChange < 0 && columnIndexLimit == board.length - 1) {
                    columnIndexLimit--;
                }

                if ((columnIndexChange > 0 && columnIndexLimit < 0)
                        || (columnIndexChange < 0 && columnIndexLimit > board.length - 1)) {
                    break;
                }
            }
        }

        return result;
    }

    private int GetStableDiscsFromEdge(int[][] board, int color, int edgeCoordinate, boolean isHorizontal) {
        int result = 0;

        if (IsEdgeFull(board, edgeCoordinate, isHorizontal)) {
            boolean oppositeColorDiscsPassed = false;
            for (int otherCoordinate = 0; otherCoordinate < board.length; otherCoordinate++) {
                int fieldColor = (isHorizontal) ? board[edgeCoordinate][otherCoordinate] : board[otherCoordinate][edgeCoordinate];
                if (fieldColor != color) {
                    oppositeColorDiscsPassed = true;
                } else if (oppositeColorDiscsPassed) {
                    int consecutiveDiscsCount = 0;
                    while ((otherCoordinate < board.length) && (fieldColor == color)) {
                        consecutiveDiscsCount++;

                        otherCoordinate++;
                        if (otherCoordinate < board.length) {
                            fieldColor = (isHorizontal) ? board[edgeCoordinate][ otherCoordinate] : board[otherCoordinate][edgeCoordinate];
                        }
                    }
                    if (otherCoordinate != board.length) {
                        result += consecutiveDiscsCount;
                        oppositeColorDiscsPassed = true;
                    }
                }
            }
        }

        return result;
    }

    private boolean IsEdgeFull(int[][] board, int edgeCoordinate, boolean isHorizontal) {
        for (int otherCoordinate = 0; otherCoordinate < board.length; otherCoordinate++) {
            if (isHorizontal && (board[edgeCoordinate][otherCoordinate] == -1)
                    || !isHorizontal && (board[otherCoordinate][edgeCoordinate] == -1)) {
                return false;
            }
        }
        return true;
    }

  
    int[][] Copy(int[][] board) {
        int size = board.length;
        int[][] newBoard = new int[size][size];
        for (int i = 0; i < size; i++) {
            System.arraycopy(board[i], 0, newBoard[i], 0, size);
        }
        return newBoard;
    }

    List<Point> getPossibleMoves(int color) {
        List<Point> possibleMoves = new ArrayList<Point>();
        for (int i = 0; i < PlayerIliusvla.height; i++) {
            for (int j = 0; j < PlayerIliusvla.width; j++) {
                boolean checkMove = moveIsLegal(i, j, color, PlayerIliusvla.changeColor(color));
                if (checkMove == true) {
                    possibleMoves.add(new Point(i, j));
                }
            }
        }
        return (possibleMoves);
    }

    boolean moveIsLegal(int m, int n, int color, int opponentColor) {
        
        if (this.board[m][n] != -1) {//If it's nofree player can't do this move
            return false;
        }
        for (int dx : dxArr) {//x-Search matrix
            for (int dy : dyArr) {//y-Search matrix                
                if (outOfBounds(m + dx, n + dy)) {
                    continue;
                }
                int x;
                int y;
                for (x = m + dx, y = n + dy; this.board[x][y] == opponentColor && x + dx < PlayerIliusvla.width
                        && y + dy < PlayerIliusvla.height && x + dx >= 0 && y + dy >= 0; x += dx, y += dy);
                if (this.board[x][y] == color && (x - dx != m || y - dy != n)) {
                    return true;
                }
            }
        }
        return false;
    }

    boolean outOfBounds(int x, int y) {
      
        return x < 0 || y < 0 || x >= PlayerIliusvla.width || y >= PlayerIliusvla.height;
    }

    boolean checkMove(int x, int y, int color, boolean change) {
      
        if (outOfBounds(x, y)) {
            return false;
        }
 
        if (board[x][y] >= 0) {
            return false;
        }

        boolean directionChecker = false;
        for (int i : dxArr) {
            for (int j : dyArr) {
                directionChecker |= checkDirection(i, j, x, y, color, change);
            }
        }

        if (directionChecker && change) {
            board[x][y] = color;
        }
        return directionChecker;
    }

    /**
     * Used this function: http://pastebin.com/ddi1k3N3
     *
     * @param dirX direction X
     * @param dirY direction Y
     * @param x
     * @param y
     * @param color
     * @param change
     */
    boolean checkDirection(int dirX, int dirY, int x, int y, int color, boolean change) {
        boolean neighbourOpponent = false;
        boolean endingMyStone = false;
        int steps = 0;
        while (!endingMyStone) {
            x += dirX;
            y += dirY;
            steps++;
            if (outOfBounds(x, y)) {
                return false;
            }
            int colorXY = board[x][y];
            if (colorXY < 0) {
                return false;
            }
            if (colorXY != color) {
                neighbourOpponent = true;
            } else {
                endingMyStone = true;
            }
        }
        if (neighbourOpponent && endingMyStone) {
            if (change) {
                dirX *= -1;
                dirY *= -1;
                for (int i = 1; i < steps; i++) {
                    x += dirX;
                    y += dirY;
                    board[x][y] = color;
                }
            }
            return true;
        }
        return false;
    }
}